/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { CheckoutModal } from './components/CheckoutModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { TrackOrderModal } from './components/TrackOrderModal';
import { AdminPanel } from './components/AdminPanel';
import { Footer } from './components/Footer';
import {
  Sparkles,
  SlidersHorizontal,
  ArrowUpDown,
  QrCode,
  ShieldCheck,
  Truck,
  RotateCcw,
  Zap,
  Phone,
  MessageCircle,
  Package,
} from 'lucide-react';
import { ProductCategory, ProductSubCategory } from './types';

const MainStoreContent: React.FC = () => {
  const {
    products,
    selectedCategory,
    setSelectedCategory,
    selectedSubCategory,
    setSelectedSubCategory,
    searchQuery,
    setSearchQuery,
    settings,
    setIsAdminOpen,
    t,
    language,
  } = useStore();

  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');

  // Filter products by category, subCategory, and search query
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Category filter
      if (selectedCategory !== 'all' && p.category !== selectedCategory) {
        return false;
      }
      // SubCategory filter
      if (selectedSubCategory !== 'all' && p.subCategory !== selectedSubCategory) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = p.name.toLowerCase().includes(q);
        const matchesHindi = p.hindiName ? p.hindiName.toLowerCase().includes(q) : false;
        const matchesDesc = p.description.toLowerCase().includes(q);
        const matchesSub = p.subCategory.toLowerCase().includes(q);
        if (!matchesName && !matchesHindi && !matchesDesc && !matchesSub) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // featured default
    });
  }, [products, selectedCategory, selectedSubCategory, searchQuery, sortBy]);

  const subCategoriesList: { id: ProductSubCategory; label: string; icon: string }[] = [
    { id: 'all', label: t('All Styles', 'सभी स्टाइल्स'), icon: '✨' },
    { id: 't-shirts', label: t('T-Shirts', 'टी-शर्ट्स'), icon: '👕' },
    { id: 'shirts', label: t('Shirts', 'शर्ट्स'), icon: '👔' },
    { id: 'jeans', label: t('Jeans & Denim', 'जीन्स व डेनिम'), icon: '👖' },
    { id: 'hoodies', label: t('Hoodies & Fleece', 'हुडीज़ व फ्लीस'), icon: '🧥' },
  ];

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-amber-500 selection:text-black">
      <Navbar />

      <main className="flex-1">
        {/* Hero Section */}
        <HeroBanner />

        {/* Catalog Section */}
        <section id="catalog" className="container mx-auto px-4 py-10 sm:py-14 space-y-8">
          {/* Section Title & Main Category Tabs */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-neutral-800 pb-5">
            <div>
              <div className="flex items-center gap-2 text-amber-500 text-xs font-bold uppercase tracking-wider mb-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t('EXPLORE THE CATALOG', 'कलेक्शन्स एक्सप्लोर करें')}</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white font-heading">
                {selectedCategory === 'all'
                  ? t("Men's & Women's Drop", 'मेन्स व वुमेन्स कलेक्शन्स')
                  : selectedCategory === 'men'
                  ? t("Men's Streetwear Collection", 'मेन्स स्ट्रीटवियर कलेक्शन')
                  : t("Women's Streetwear Collection", 'वुमेन्स स्ट्रीटवियर कलेक्शन')}
              </h2>
            </div>

            {/* Gender Switcher Pill */}
            <div className="flex items-center bg-neutral-900 p-1.5 rounded-2xl border border-neutral-800 self-start md:self-auto">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  selectedCategory === 'all'
                    ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {t('All Items', 'सभी कपड़े')}
              </button>
              <button
                onClick={() => setSelectedCategory('men')}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  selectedCategory === 'men'
                    ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {t("Men's", 'मेन्स (Men)')}
              </button>
              <button
                onClick={() => setSelectedCategory('women')}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  selectedCategory === 'women'
                    ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {t("Women's", 'वुमेन्स (Women)')}
              </button>
            </div>
          </div>

          {/* Sub-Category Chips & Sorting Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Subcategories (T-shirts, shirts, jeans, hoodies) */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
              {subCategoriesList.map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => setSelectedSubCategory(sub.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                    selectedSubCategory === sub.id
                      ? 'bg-neutral-100 text-neutral-900 font-bold shadow-md'
                      : 'bg-neutral-900/90 text-neutral-400 hover:text-white border border-neutral-800'
                  }`}
                >
                  <span>{sub.icon}</span>
                  <span>{sub.label}</span>
                </button>
              ))}
            </div>

            {/* Sorting Dropdown */}
            <div className="flex items-center gap-2 self-end sm:self-auto">
              <ArrowUpDown className="w-3.5 h-3.5 text-neutral-500" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs rounded-xl px-3 py-2 outline-none cursor-pointer"
              >
                <option value="featured">Featured / लोकप्रिय</option>
                <option value="price-asc">Price: Low to High (कम से ज्यादा)</option>
                <option value="price-desc">Price: High to Low (ज्यादा से कम)</option>
                <option value="rating">Highest Rated (बेस्ट रेटिंग)</option>
              </select>
            </div>
          </div>

          {/* Active Filter Indicators */}
          {(searchQuery || selectedCategory !== 'all' || selectedSubCategory !== 'all') && (
            <div className="flex items-center gap-2 text-xs text-neutral-400 bg-neutral-900/60 p-2.5 rounded-xl border border-neutral-800/80">
              <span>Showing results for:</span>
              {selectedCategory !== 'all' && (
                <span className="bg-neutral-800 text-amber-400 px-2 py-0.5 rounded font-medium">
                  {selectedCategory.toUpperCase()}
                </span>
              )}
              {selectedSubCategory !== 'all' && (
                <span className="bg-neutral-800 text-amber-400 px-2 py-0.5 rounded font-medium capitalize">
                  {selectedSubCategory}
                </span>
              )}
              {searchQuery && (
                <span className="bg-neutral-800 text-white px-2 py-0.5 rounded">
                  "{searchQuery}"
                </span>
              )}
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSelectedSubCategory('all');
                  setSearchQuery('');
                }}
                className="ml-auto text-amber-400 hover:underline cursor-pointer"
              >
                Clear all filters
              </button>
            </div>
          )}

          {/* Product Grid */}
          {filteredProducts.length === 0 ? (
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-3xl p-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-500 mx-auto">
                <SlidersHorizontal className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-white">
                {t('No products found', 'कोई प्रोडक्ट नहीं मिला')}
              </h3>
              <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                {t(
                  'Try resetting your search query or switching category filters.',
                  'कृपया दूसरा कीवर्ड सर्च करें या फ़िल्टर हटाकर देखें।'
                )}
              </p>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSelectedSubCategory('all');
                  setSearchQuery('');
                }}
                className="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs transition-colors cursor-pointer"
              >
                {t('Show All Products', 'सभी प्रोडक्ट्स दिखाएं')}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </section>

        {/* UPI Payment Flow Feature Banner */}
        <section className="container mx-auto px-4 py-8">
          <div className="bg-gradient-to-r from-neutral-900 via-neutral-900/90 to-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-10 relative overflow-hidden">
            <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-amber-500/5 blur-3xl pointer-events-none" />

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7 space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
                  <QrCode className="w-3.5 h-3.5" />
                  <span>DIRECT SCAN & PAY VIA UPI</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-black text-white font-heading">
                  Seamless Payment with UPI QR Code
                </h3>
                <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed max-w-xl">
                  {t(
                    'Order directly in seconds! Simply click "Order Now", fill in your address, scan the generated UPI QR code with GPay, PhonePe, Paytm, or BHIM, and your order is booked instantly.',
                    'बस किसी भी प्रोडक्ट पर "Order Now" दबाएं, अपना पता भरें और स्क्रीन पर बने UPI QR कोड को स्कैन करके पेमेंट करें। कोई झंझट नहीं, तुरंत आर्डर कन्फर्म!'
                  )}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  <div className="bg-neutral-950/80 p-3.5 rounded-2xl border border-neutral-800 text-xs space-y-1">
                    <span className="text-amber-400 font-bold">1. Tap Order Now</span>
                    <p className="text-neutral-400 text-[11px]">Select size, enter delivery address.</p>
                  </div>
                  <div className="bg-neutral-950/80 p-3.5 rounded-2xl border border-neutral-800 text-xs space-y-1">
                    <span className="text-amber-400 font-bold">2. Scan UPI QR</span>
                    <p className="text-neutral-400 text-[11px]">Pay via GPay, PhonePe or Paytm.</p>
                  </div>
                  <div className="bg-neutral-950/80 p-3.5 rounded-2xl border border-neutral-800 text-xs space-y-1">
                    <span className="text-amber-400 font-bold">3. Enter UTR & Confirm</span>
                    <p className="text-neutral-400 text-[11px]">Instant receipt on WhatsApp & screen.</p>
                  </div>
                </div>
              </div>

              {/* UPI Card Graphic */}
              <div className="lg:col-span-5 flex justify-center">
                <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-5 shadow-2xl max-w-xs w-full text-center space-y-3">
                  <div className="flex items-center justify-between text-xs text-neutral-400 border-b border-neutral-800 pb-2">
                    <span className="font-brand font-bold text-white">🦂 Scorpion Pay</span>
                    <span className="text-emerald-400 font-bold">NPCI Verified</span>
                  </div>
                  <div className="p-3 bg-white rounded-xl inline-block shadow-inner">
                    <div className="w-32 h-32 bg-neutral-900 rounded flex flex-col items-center justify-center text-white p-2 text-center">
                      <QrCode className="w-12 h-12 text-amber-400 mb-1" />
                      <span className="text-[9px] font-mono font-bold tracking-wider text-neutral-300">
                        DYNAMIC UPI QR
                      </span>
                    </div>
                  </div>
                  <div className="text-xs">
                    <span className="text-neutral-500 block text-[10px]">Merchant UPI VPA</span>
                    <span className="font-mono text-amber-400 font-bold">{settings.upiId}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Floating Bottom Quick Action for Mobile */}
      <div className="fixed bottom-4 right-4 z-30 flex flex-col gap-2.5">
        {/* WhatsApp Direct Help */}
        <a
          href={`https://wa.me/${settings.whatsappNumber.replace(/\D/g, '')}?text=Hello%20Scorpion%20clothings,%20I%20have%20a%20question`}
          target="_blank"
          rel="noreferrer"
          className="w-12 h-12 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-2xl shadow-emerald-950/60 transition-transform hover:scale-110 cursor-pointer"
          title="WhatsApp Support"
        >
          <MessageCircle className="w-6 h-6" />
        </a>

        {/* Admin Quick Switcher */}
        <button
          onClick={() => setIsAdminOpen(true)}
          className="w-12 h-12 rounded-full bg-neutral-900 border border-neutral-700 hover:border-amber-500 text-amber-400 flex items-center justify-center shadow-2xl transition-transform hover:scale-110 cursor-pointer"
          title="Open Admin Panel"
        >
          <span className="text-xs font-black">ADM</span>
        </button>
      </div>

      {/* Global Modals & Drawers */}
      <ProductModal />
      <CheckoutModal />
      <CartDrawer />
      <WishlistDrawer />
      <TrackOrderModal />
      <AdminPanel />
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <MainStoreContent />
    </StoreProvider>
  );
}
