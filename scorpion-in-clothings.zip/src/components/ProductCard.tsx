import React, { useState } from 'react';
import { Heart, Star, Zap, ShoppingBag, Eye, Check } from 'lucide-react';
import { Product, ProductSize } from '../types';
import { useStore } from '../context/StoreContext';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const {
    openDirectCheckout,
    addToCart,
    toggleWishlist,
    isInWishlist,
    setSelectedProductForModal,
    t,
    language,
  } = useStore();

  const [selectedSize, setSelectedSize] = useState<ProductSize>(
    product.sizes[0] || 'L'
  );
  const [isHovered, setIsHovered] = useState(false);
  const [justAdded, setJustAdded] = useState(false);

  const isFavorited = isInWishlist(product.id);

  const handleOrderNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    openDirectCheckout(product, selectedSize, product.colors[0], 1);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, selectedSize, product.colors[0], 1);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1800);
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  return (
    <div
      onClick={() => setSelectedProductForModal(product)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative bg-neutral-900/90 border border-neutral-800/80 hover:border-amber-500/50 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-2xl hover:shadow-amber-500/10 flex flex-col cursor-pointer"
    >
      {/* Image Area */}
      <div className="relative aspect-[3/4] overflow-hidden bg-neutral-950">
        <img
          src={isHovered && product.images[1] ? product.images[1] : product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-108"
          loading="lazy"
        />

        {/* Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
          {product.badge && (
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500 text-black shadow-md">
              {product.badge}
            </span>
          )}
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-neutral-950/80 backdrop-blur-md text-emerald-400 border border-emerald-500/30">
            {product.discountPercent}% OFF
          </span>
        </div>

        {/* Top Right Wishlist & Quick View */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 z-10">
          <button
            type="button"
            onClick={handleToggleWishlist}
            aria-label="Add to wishlist"
            className={`w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-transform duration-200 hover:scale-110 cursor-pointer ${
              isFavorited
                ? 'bg-rose-500 text-white'
                : 'bg-black/60 text-neutral-300 hover:text-white'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorited ? 'fill-white' : ''}`} />
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedProductForModal(product);
            }}
            className="w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 text-neutral-300 hover:text-white flex items-center justify-center backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer hidden sm:flex"
            title="Quick view"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>

        {/* Category tag watermark */}
        <div className="absolute bottom-2 left-2.5 bg-black/70 backdrop-blur-sm px-2 py-0.5 rounded text-[10px] font-medium text-neutral-300 uppercase tracking-wider">
          {product.category} • {product.subCategory}
        </div>
      </div>

      {/* Content Area */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* Rating */}
          <div className="flex items-center gap-1.5 text-xs text-neutral-400 mb-1">
            <div className="flex items-center text-amber-400 font-bold">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
              <span className="ml-1 text-[11px]">{product.rating}</span>
            </div>
            <span className="text-[11px] text-neutral-500">({product.reviewsCount})</span>
            {product.inStock && (
              <span className="text-[10px] text-emerald-400 ml-auto font-medium">In Stock</span>
            )}
          </div>

          {/* Title */}
          <h3 className="font-semibold text-white text-sm line-clamp-1 group-hover:text-amber-400 transition-colors">
            {language === 'hi' && product.hindiName ? product.hindiName : product.name}
          </h3>

          <p className="text-xs text-neutral-400 line-clamp-1 mt-0.5">
            {language === 'hi' && product.hindiDescription ? product.hindiDescription : product.description}
          </p>

          {/* Price */}
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-lg font-bold text-white">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
            <span className="text-xs text-neutral-500 line-through">
              ₹{product.originalPrice.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Size Selection Chips */}
        <div className="space-y-1.5 pt-1">
          <div className="text-[11px] text-neutral-400 flex items-center justify-between">
            <span>Size:</span>
            <span className="text-amber-400 font-bold">{selectedSize}</span>
          </div>
          <div className="flex gap-1.5 flex-wrap">
            {product.sizes.map((s) => (
              <button
                key={s}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedSize(s);
                }}
                className={`px-2 py-0.5 text-[10px] font-semibold rounded-md transition-all cursor-pointer ${
                  selectedSize === s
                    ? 'bg-amber-500 text-black font-bold'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Buttons: Explicit "Order Now" button & "Add to Cart" */}
        <div className="grid grid-cols-2 gap-2 pt-2">
          {/* ORDER NOW BUTTON - Highlighted as requested */}
          <button
            type="button"
            onClick={handleOrderNow}
            className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 transition-all cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
          >
            <Zap className="w-3.5 h-3.5 fill-black" />
            <span>{t('Order Now', 'Order Now')}</span>
          </button>

          {/* ADD TO CART BUTTON */}
          <button
            type="button"
            onClick={handleAddToCart}
            className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 border border-neutral-700/80 transition-colors cursor-pointer"
          >
            {justAdded ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Added!</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>{t('Cart', 'कार्ट')}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
