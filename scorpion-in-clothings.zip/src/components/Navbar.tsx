import React, { useState } from 'react';
import {
  ShoppingBag,
  Heart,
  Search,
  Shield,
  Menu,
  X,
  Package,
  Globe,
  Truck,
  Sparkles,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { ProductCategory, ProductSubCategory } from '../types';

export const Navbar: React.FC = () => {
  const {
    settings,
    cartCount,
    wishlist,
    setIsCartOpen,
    setIsWishlistOpen,
    setIsAdminOpen,
    setIsTrackOrderOpen,
    selectedCategory,
    setSelectedCategory,
    selectedSubCategory,
    setSelectedSubCategory,
    searchQuery,
    setSearchQuery,
    language,
    setLanguage,
    t,
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSearchInput, setShowSearchInput] = useState(false);

  const navCategories = [
    { label: t('All Items', 'सभी कपड़े'), cat: 'all', sub: 'all' },
    { label: t("Men's", 'मेन्स कलेक्शन'), cat: 'men', sub: 'all' },
    { label: t("Women's", 'वुमेन्स कलेक्शन'), cat: 'women', sub: 'all' },
    { label: t('T-Shirts', 'टी-शर्ट्स'), cat: 'all', sub: 't-shirts' },
    { label: t('Shirts', 'शर्ट्स'), cat: 'all', sub: 'shirts' },
    { label: t('Jeans', 'जीन्स'), cat: 'all', sub: 'jeans' },
    { label: t('Hoodies', 'हुडीज़'), cat: 'all', sub: 'hoodies' },
  ];

  const handleSelectNav = (cat: string, sub: string) => {
    setSelectedCategory(cat as ProductCategory);
    setSelectedSubCategory(sub as ProductSubCategory);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-neutral-950/95 backdrop-blur-md border-b border-neutral-900 transition-all">
      {/* Top Banner Notice */}
      <div className="bg-gradient-to-r from-neutral-950 via-amber-950/40 to-neutral-950 border-b border-amber-500/20 py-1.5 px-4 text-center">
        <div className="container mx-auto flex items-center justify-between text-[11px] text-neutral-300">
          <div className="hidden sm:flex items-center gap-1.5 text-amber-400">
            <Sparkles className="w-3.5 h-3.5 animate-pulse" />
            <span className="font-semibold">STREETWEAR SEASON 2026</span>
          </div>
          <div className="mx-auto sm:mx-0 font-medium truncate">
            {settings.noticeBanner}
          </div>
          <div className="hidden sm:flex items-center gap-3 text-neutral-400">
            <button
              onClick={() => setIsTrackOrderOpen(true)}
              className="hover:text-amber-400 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Truck className="w-3.5 h-3.5" />
              <span>Track Order</span>
            </button>
            <span>•</span>
            <button
              onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
              className="text-amber-400 hover:text-amber-300 font-semibold cursor-pointer"
            >
              {language === 'hi' ? 'English' : 'हिंदी'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="container mx-auto px-4 py-3 sm:py-3.5 flex items-center justify-between gap-4">
        {/* Mobile Hamburger */}
        <div className="flex items-center gap-2 lg:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 rounded-xl bg-neutral-900 text-neutral-300 hover:text-white cursor-pointer"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Brand Logo */}
        <div
          onClick={() => {
            setSelectedCategory('all');
            setSelectedSubCategory('all');
            setSearchQuery('');
          }}
          className="flex items-center gap-2.5 cursor-pointer group select-none"
        >
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center text-black font-extrabold text-xl shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform">
            🦂
          </div>
          <div>
            <span className="font-brand font-black text-lg sm:text-2xl tracking-wider text-white uppercase group-hover:text-amber-400 transition-colors block leading-none">
              Scorpion
            </span>
            <span className="text-[10px] sm:text-xs uppercase tracking-[0.25em] text-amber-500/90 font-bold block leading-tight">
              In clothings
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 bg-neutral-900/60 p-1 rounded-2xl border border-neutral-800/80">
          {navCategories.map((item, idx) => {
            const isActive =
              (item.cat === 'all' && item.sub === 'all' && selectedCategory === 'all' && selectedSubCategory === 'all') ||
              (item.cat !== 'all' && selectedCategory === item.cat && selectedSubCategory === 'all') ||
              (item.sub !== 'all' && selectedSubCategory === item.sub);

            return (
              <button
                key={idx}
                onClick={() => handleSelectNav(item.cat, item.sub)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20 font-bold'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Right Action Icons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Search bar desktop */}
          <div className="relative hidden md:block w-48 lg:w-56">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('Search tees, hoodies...', 'सर्च करें: टी-शर्ट, हुडी...')}
              className="w-full bg-neutral-900/90 border border-neutral-800 focus:border-amber-500/80 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-neutral-500 outline-none transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-white text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Search mobile toggle */}
          <button
            onClick={() => setShowSearchInput(!showSearchInput)}
            className="md:hidden p-2 rounded-xl bg-neutral-900 text-neutral-300 hover:text-white cursor-pointer"
            aria-label="Search"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Track order mobile shortcut */}
          <button
            onClick={() => setIsTrackOrderOpen(true)}
            className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer sm:hidden"
            title="Track Order"
          >
            <Package className="w-4 h-4" />
          </button>

          {/* Wishlist Button */}
          <button
            onClick={() => setIsWishlistOpen(true)}
            className="relative p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
            aria-label="Wishlist"
          >
            <Heart className="w-4 h-4" />
            {wishlist.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Cart Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative flex items-center gap-2 py-1.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs transition-colors cursor-pointer shadow-md shadow-amber-500/20"
            aria-label="Shopping Cart"
          >
            <ShoppingBag className="w-4 h-4 fill-black" />
            <span>{cartCount}</span>
          </button>

          {/* Admin Mode Shortcut Button */}
          <button
            onClick={() => setIsAdminOpen(true)}
            className="hidden sm:flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-amber-500/50 text-neutral-300 hover:text-amber-400 text-xs font-semibold transition-colors cursor-pointer"
            title="Open Admin Panel"
          >
            <Shield className="w-3.5 h-3.5 text-amber-500" />
            <span>Admin</span>
          </button>
        </div>
      </div>

      {/* Mobile search bar dropdown */}
      {showSearchInput && (
        <div className="p-3 border-t border-neutral-900 bg-neutral-950 md:hidden">
          <div className="relative">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              autoFocus
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="सर्च करें: टी-शर्ट, हुडी, जीन्स..."
              className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-neutral-500 outline-none"
            />
          </div>
        </div>
      )}

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-neutral-900 bg-neutral-950 p-4 space-y-2">
          <div className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 px-2">
            Categories:
          </div>
          <div className="grid grid-cols-2 gap-2">
            {navCategories.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSelectNav(item.cat, item.sub)}
                className="text-left px-3 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-xs font-semibold text-neutral-200 cursor-pointer"
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-neutral-900 flex items-center justify-between text-xs px-2">
            <button
              onClick={() => {
                setIsTrackOrderOpen(true);
                setMobileMenuOpen(false);
              }}
              className="text-amber-400 font-semibold flex items-center gap-1.5"
            >
              <Package className="w-4 h-4" />
              <span>{t('Track Order', 'ऑर्डर ट्रैक करें')}</span>
            </button>

            <button
              onClick={() => {
                setIsAdminOpen(true);
                setMobileMenuOpen(false);
              }}
              className="text-neutral-400 hover:text-white flex items-center gap-1.5"
            >
              <Shield className="w-4 h-4 text-amber-500" />
              <span>Admin Panel</span>
            </button>

            <button
              onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
              className="text-neutral-400 hover:text-white flex items-center gap-1"
            >
              <Globe className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'hi' ? 'EN' : 'हिंदी'}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
