import React from 'react';
import { X, Heart, Trash2, Zap } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const WishlistDrawer: React.FC = () => {
  const {
    isWishlistOpen,
    setIsWishlistOpen,
    wishlist,
    products,
    toggleWishlist,
    openDirectCheckout,
    t,
  } = useStore();

  if (!isWishlistOpen) return null;

  const wishlistProducts = products.filter((p) => wishlist.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div
        onClick={() => setIsWishlistOpen(false)}
        className="fixed inset-0 bg-black/75 backdrop-blur-sm transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-neutral-900 border-l border-neutral-800 text-white flex flex-col shadow-2xl">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/80">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-500">
                <Heart className="w-4 h-4 fill-rose-500" />
              </div>
              <h3 className="font-bold text-base sm:text-lg">
                {t('My Wishlist', 'मेरी विशलिस्ट')} ({wishlist.length})
              </h3>
            </div>
            <button
              onClick={() => setIsWishlistOpen(false)}
              className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 flex items-center justify-center text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5">
            {wishlistProducts.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
                <div className="w-16 h-16 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-500">
                  <Heart className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-base text-neutral-300">
                  {t('No items in wishlist', 'विशलिस्ट में कोई प्रोडक्ट नहीं है')}
                </h4>
                <p className="text-xs text-neutral-400 max-w-xs">
                  {t('Tap the heart icon on any product to save it here for later.', 'पसंदीदा प्रोडक्ट पर दिल के आइकॉन पर क्लिक करें।')}
                </p>
              </div>
            ) : (
              wishlistProducts.map((prod) => (
                <div
                  key={prod.id}
                  className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 flex gap-3 items-center"
                >
                  <img
                    src={prod.images[0]}
                    alt={prod.name}
                    className="w-16 h-20 object-cover rounded-lg border border-neutral-800 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-xs sm:text-sm text-white truncate">
                      {prod.name}
                    </h4>
                    <div className="font-bold text-amber-400 text-sm mt-0.5">
                      ₹{prod.price.toLocaleString('en-IN')}
                    </div>

                    <div className="flex items-center gap-2 mt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsWishlistOpen(false);
                          openDirectCheckout(prod);
                        }}
                        className="py-1 px-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Zap className="w-3 h-3 fill-black" />
                        <span>Order Now</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => toggleWishlist(prod.id)}
                        className="text-neutral-500 hover:text-rose-400 p-1 transition-colors cursor-pointer ml-auto"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
