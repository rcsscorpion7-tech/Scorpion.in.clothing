import React, { useState } from 'react';
import {
  X,
  Package,
  ShoppingBag,
  Settings,
  Plus,
  Trash2,
  Edit2,
  Phone,
  MessageCircle,
  MapPin,
  CheckCircle,
  Truck,
  RotateCcw,
  IndianRupee,
  Search,
  Check,
  Eye,
  AlertCircle,
  Printer,
  Copy,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Product, Order, OrderStatus, ProductSize } from '../types';

export const AdminPanel: React.FC = () => {
  const {
    isAdminOpen,
    setIsAdminOpen,
    orders,
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    resetProductsToDefault,
    updateOrderStatus,
    deleteOrder,
    settings,
    updateSettings,
    t,
  } = useStore();

  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'settings'>('orders');
  const [orderFilter, setOrderFilter] = useState<string>('all');
  const [orderSearch, setOrderSearch] = useState('');

  // Product Add / Edit state
  const [isEditingProduct, setIsEditingProduct] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);

  // Form states for product
  const [prodName, setProdName] = useState('');
  const [prodHindiName, setProdHindiName] = useState('');
  const [prodCategory, setProdCategory] = useState<'men' | 'women'>('men');
  const [prodSubCategory, setProdSubCategory] = useState<'t-shirts' | 'shirts' | 'jeans' | 'hoodies'>('t-shirts');
  const [prodPrice, setProdPrice] = useState('799');
  const [prodOriginalPrice, setProdOriginalPrice] = useState('1499');
  const [prodSizes, setProdSizes] = useState<ProductSize[]>(['S', 'M', 'L', 'XL']);
  const [prodImageUrl, setProdImageUrl] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodBadge, setProdBadge] = useState<'Bestseller' | 'Trending' | 'New Arrival' | 'Hot Deal'>('Trending');
  const [prodStock, setProdStock] = useState('50');

  // Settings form states
  const [storeUpiId, setStoreUpiId] = useState(settings.upiId);
  const [storeUpiName, setStoreUpiName] = useState(settings.upiPayeeName);
  const [storeWhatsApp, setStoreWhatsApp] = useState(settings.whatsappNumber);
  const [storeNotice, setStoreNotice] = useState(settings.noticeBanner);
  const [settingsSaved, setSettingsSaved] = useState(false);

  if (!isAdminOpen) return null;

  // Filtered orders
  const filteredOrders = orders.filter((o) => {
    const matchesFilter =
      orderFilter === 'all'
        ? true
        : orderFilter === 'upi' || orderFilter === 'cod'
        ? o.paymentMethod === orderFilter
        : o.orderStatus.toLowerCase() === orderFilter.toLowerCase();

    const matchesSearch =
      o.id.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.customer.name.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.customer.phone.includes(orderSearch);

    return matchesFilter && matchesSearch;
  });

  // Analytics
  const totalRevenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const placedOrdersCount = orders.filter((o) => o.orderStatus === 'Placed').length;
  const upiOrdersCount = orders.filter((o) => o.paymentMethod === 'upi').length;

  const handleOpenAddProduct = () => {
    setIsEditingProduct(true);
    setEditingProductId(null);
    setProdName('');
    setProdHindiName('');
    setProdCategory('men');
    setProdSubCategory('t-shirts');
    setProdPrice('799');
    setProdOriginalPrice('1499');
    setProdSizes(['S', 'M', 'L', 'XL']);
    setProdImageUrl('https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80');
    setProdDesc('Premium 100% cotton apparel by Scorpion In clothings.');
    setProdBadge('New Arrival');
    setProdStock('40');
  };

  const handleOpenEditProduct = (prod: Product) => {
    setIsEditingProduct(true);
    setEditingProductId(prod.id);
    setProdName(prod.name);
    setProdHindiName(prod.hindiName || '');
    setProdCategory(prod.category);
    setProdSubCategory(prod.subCategory as any);
    setProdPrice(prod.price.toString());
    setProdOriginalPrice(prod.originalPrice.toString());
    setProdSizes(prod.sizes);
    setProdImageUrl(prod.images[0] || '');
    setProdDesc(prod.description);
    setProdBadge(prod.badge || 'Trending');
    setProdStock(prod.stockCount.toString());
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseInt(prodPrice) || 699;
    const origPriceNum = parseInt(prodOriginalPrice) || priceNum * 2;
    const discount = Math.round(((origPriceNum - priceNum) / origPriceNum) * 100);

    const productPayload = {
      name: prodName,
      hindiName: prodHindiName || prodName,
      category: prodCategory,
      subCategory: prodSubCategory,
      price: priceNum,
      originalPrice: origPriceNum,
      discountPercent: discount,
      sizes: prodSizes,
      colors: [
        { name: 'Onyx Black', hex: '#0a0a0a' },
        { name: 'Smoke Grey', hex: '#374151' },
      ],
      images: [prodImageUrl || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80'],
      description: prodDesc,
      hindiDescription: prodDesc,
      features: ['100% Combed Cotton', 'Comfortable Streetwear Fit', 'High Durability'],
      fabric: '100% Cotton',
      fit: 'Relaxed Fit',
      inStock: true,
      stockCount: parseInt(prodStock) || 30,
      rating: 4.8,
      reviewsCount: 12,
      badge: prodBadge,
    };

    if (editingProductId) {
      updateProduct({
        ...productPayload,
        id: editingProductId,
      });
    } else {
      addProduct(productPayload);
    }

    setIsEditingProduct(false);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      upiId: storeUpiId.trim(),
      upiPayeeName: storeUpiName.trim(),
      whatsappNumber: storeWhatsApp.trim(),
      noticeBanner: storeNotice.trim(),
    });
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-5">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-5xl w-full max-h-[94vh] overflow-hidden flex flex-col shadow-2xl relative my-auto">
        {/* Admin Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-500 font-brand font-bold text-xl">
              🦂
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-white text-base sm:text-lg">
                  Scorpion Store Admin Portal
                </h3>
                <span className="bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  ADMIN MODE
                </span>
              </div>
              <p className="text-xs text-neutral-400">Manage Orders, Products & UPI Payment Settings</p>
            </div>
          </div>
          <button
            onClick={() => setIsAdminOpen(false)}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 flex items-center justify-center text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 border-b border-neutral-800 bg-neutral-950/40 flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => {
              setActiveTab('orders');
              setIsEditingProduct(false);
            }}
            className={`py-3 px-4 font-semibold text-xs sm:text-sm border-b-2 flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'orders'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Orders Management (ऑर्डर्स)</span>
            <span className="bg-neutral-800 px-2 py-0.5 rounded-full text-xs text-neutral-300">
              {orders.length}
            </span>
          </button>

          <button
            onClick={() => {
              setActiveTab('products');
              setIsEditingProduct(false);
            }}
            className={`py-3 px-4 font-semibold text-xs sm:text-sm border-b-2 flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'products'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Products Catalog (प्रोडक्ट्स)</span>
            <span className="bg-neutral-800 px-2 py-0.5 rounded-full text-xs text-neutral-300">
              {products.length}
            </span>
          </button>

          <button
            onClick={() => {
              setActiveTab('settings');
              setIsEditingProduct(false);
            }}
            className={`py-3 px-4 font-semibold text-xs sm:text-sm border-b-2 flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'settings'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>UPI & Store Settings (सेटिंग्स)</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-neutral-950 border border-neutral-800 p-3.5 rounded-2xl">
              <span className="text-[11px] text-neutral-400">Total Orders</span>
              <div className="text-xl font-extrabold text-white mt-0.5">{orders.length}</div>
            </div>
            <div className="bg-neutral-950 border border-neutral-800 p-3.5 rounded-2xl">
              <span className="text-[11px] text-neutral-400">Total Revenue</span>
              <div className="text-xl font-extrabold text-amber-400 mt-0.5">
                ₹{totalRevenue.toLocaleString('en-IN')}
              </div>
            </div>
            <div className="bg-neutral-950 border border-neutral-800 p-3.5 rounded-2xl">
              <span className="text-[11px] text-neutral-400">Placed / Pending</span>
              <div className="text-xl font-extrabold text-rose-400 mt-0.5">{placedOrdersCount}</div>
            </div>
            <div className="bg-neutral-950 border border-neutral-800 p-3.5 rounded-2xl">
              <span className="text-[11px] text-neutral-400">UPI Payments</span>
              <div className="text-xl font-extrabold text-emerald-400 mt-0.5">{upiOrdersCount}</div>
            </div>
          </div>

          {/* TAB 1: ORDERS MANAGEMENT */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              {/* Order filters & search */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-neutral-950 p-3 rounded-2xl border border-neutral-800">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={orderSearch}
                    onChange={(e) => setOrderSearch(e.target.value)}
                    placeholder="Search by Order ID, Customer name or Mobile..."
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-neutral-500 outline-none"
                  />
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                  {['all', 'Placed', 'Processing', 'Shipped', 'Delivered', 'upi'].map(
                    (f) => (
                      <button
                        key={f}
                        onClick={() => setOrderFilter(f)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                          orderFilter === f
                            ? 'bg-amber-500 text-black'
                            : 'bg-neutral-900 text-neutral-300 hover:bg-neutral-800'
                        }`}
                      >
                        {f.toUpperCase()}
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Orders List */}
              {filteredOrders.length === 0 ? (
                <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-8 text-center text-neutral-500 text-xs">
                  No orders found matching the filter criteria.
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredOrders.map((order) => (
                    <div
                      key={order.id}
                      className="bg-neutral-950 border border-neutral-800 rounded-2xl p-4 sm:p-5 space-y-4"
                    >
                      {/* Order Header */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800/80 pb-3">
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-amber-400 text-base">
                            {order.id}
                          </span>
                          <span className="text-xs text-neutral-400">
                            {new Date(order.createdAt).toLocaleDateString('en-IN', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>

                        {/* Status Changer */}
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-neutral-400">Status:</span>
                          <select
                            value={order.orderStatus}
                            onChange={(e) =>
                              updateOrderStatus(order.id, e.target.value as OrderStatus)
                            }
                            className="bg-neutral-900 border border-neutral-700 text-white rounded-lg px-2.5 py-1 text-xs font-bold outline-none cursor-pointer"
                          >
                            <option value="Placed">Placed (नया ऑर्डर)</option>
                            <option value="Processing">Processing (तैयार हो रहा)</option>
                            <option value="Shipped">Shipped (डिस्पैच हुआ)</option>
                            <option value="Delivered">Delivered (डिलीवर हो गया)</option>
                            <option value="Cancelled">Cancelled (रद्द)</option>
                          </select>

                          <button
                            onClick={() => deleteOrder(order.id)}
                            className="p-1.5 text-neutral-500 hover:text-rose-400 transition-colors cursor-pointer"
                            title="Delete order"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Customer Details & Actions */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                        {/* Customer Box */}
                        <div className="bg-neutral-900/60 p-3.5 rounded-xl border border-neutral-800 space-y-1.5">
                          <div className="font-bold text-white text-sm flex items-center justify-between">
                            <span>{order.customer.name}</span>
                            <span className="text-amber-400 font-mono font-bold text-sm">
                              ₹{order.totalAmount.toLocaleString('en-IN')}
                            </span>
                          </div>

                          <div className="flex items-center gap-3 pt-1">
                            <a
                              href={`tel:${order.customer.phone}`}
                              className="text-amber-400 hover:underline flex items-center gap-1 font-mono"
                            >
                              <Phone className="w-3.5 h-3.5" />
                              <span>+91 {order.customer.phone}</span>
                            </a>
                            <a
                              href={`https://wa.me/91${order.customer.phone}?text=Hello%20${encodeURIComponent(
                                order.customer.name
                              )},%20regarding%20your%20Scorpion%20clothings%20order%20${order.id}...`}
                              target="_blank"
                              rel="noreferrer"
                              className="text-emerald-400 hover:underline flex items-center gap-1"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              <span>WhatsApp</span>
                            </a>
                          </div>

                          <div className="text-neutral-400 flex items-start gap-1.5 pt-1">
                            <MapPin className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                            <span>
                              {order.customer.address}, {order.customer.city},{' '}
                              {order.customer.state} - {order.customer.pincode}
                              {order.customer.landmark ? ` (Near: ${order.customer.landmark})` : ''}
                            </span>
                          </div>
                        </div>

                        {/* Payment & Items Box */}
                        <div className="bg-neutral-900/60 p-3.5 rounded-xl border border-neutral-800 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1.5">
                              <span className="font-semibold text-neutral-300">Payment:</span>
                              <span className="uppercase font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                                {order.paymentMethod}
                              </span>
                            </div>
                            {order.upiTxnId && (
                              <div className="text-[11px] text-neutral-300 font-mono bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800">
                                UTR: <strong className="text-emerald-400">{order.upiTxnId}</strong>
                              </div>
                            )}
                          </div>

                          {/* Ordered products */}
                          <div className="space-y-1 pt-1 max-h-24 overflow-y-auto">
                            {order.items.map((it, idx) => (
                              <div
                                key={idx}
                                className="flex items-center justify-between text-[11px] text-neutral-400"
                              >
                                <span className="text-white truncate max-w-[200px]">
                                  • {it.product.name} ({it.selectedSize})
                                </span>
                                <span>
                                  x{it.quantity} = ₹{(it.product.price * it.quantity).toLocaleString('en-IN')}
                                </span>
                              </div>
                            ))}
                          </div>

                          {order.notes && (
                            <div className="text-[11px] text-amber-300/80 italic pt-1">
                              Note: {order.notes}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: PRODUCTS CATALOG */}
          {activeTab === 'products' && (
            <div className="space-y-4">
              {!isEditingProduct ? (
                <>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-white text-base">Store Products</h4>
                      <p className="text-xs text-neutral-400">Add, update or remove items from the catalog</p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={resetProductsToDefault}
                        className="py-2 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-semibold transition-colors cursor-pointer"
                      >
                        Reset Defaults
                      </button>
                      <button
                        onClick={handleOpenAddProduct}
                        className="py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add New Product</span>
                      </button>
                    </div>
                  </div>

                  {/* Products Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {products.map((prod) => (
                      <div
                        key={prod.id}
                        className="bg-neutral-950 border border-neutral-800 rounded-2xl p-3 flex gap-3 items-center"
                      >
                        <img
                          src={prod.images[0]}
                          alt={prod.name}
                          className="w-16 h-20 object-cover rounded-xl border border-neutral-800 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <span className="text-[10px] uppercase font-bold text-amber-500">
                            {prod.category} • {prod.subCategory}
                          </span>
                          <h5 className="font-bold text-xs text-white truncate">{prod.name}</h5>
                          <div className="flex items-baseline gap-1.5 mt-0.5">
                            <span className="font-bold text-white text-sm">₹{prod.price}</span>
                            <span className="text-[11px] text-neutral-500 line-through">
                              ₹{prod.originalPrice}
                            </span>
                          </div>
                          <div className="text-[11px] text-neutral-400 mt-1">
                            Stock: {prod.stockCount} | Sizes: {prod.sizes.join(', ')}
                          </div>

                          <div className="flex gap-2 mt-2">
                            <button
                              onClick={() => handleOpenEditProduct(prod)}
                              className="px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-xs text-neutral-200 flex items-center gap-1 cursor-pointer"
                            >
                              <Edit2 className="w-3 h-3" />
                              <span>Edit</span>
                            </button>
                            <button
                              onClick={() => deleteProduct(prod.id)}
                              className="px-2 py-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs flex items-center gap-1 cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Delete</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                /* Add / Edit Form */
                <form
                  onSubmit={handleSaveProduct}
                  className="bg-neutral-950 border border-neutral-800 rounded-2xl p-5 space-y-4"
                >
                  <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                    <h4 className="font-bold text-white text-base">
                      {editingProductId ? 'Edit Product' : 'Add New Apparel Product'}
                    </h4>
                    <button
                      type="button"
                      onClick={() => setIsEditingProduct(false)}
                      className="text-xs text-neutral-400 hover:text-white"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        Product Name (English)*
                      </label>
                      <input
                        type="text"
                        required
                        value={prodName}
                        onChange={(e) => setProdName(e.target.value)}
                        placeholder="e.g. Scorpion Oversized Cotton Tee"
                        className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        Product Name (हिंदी - वैकल्पिक)
                      </label>
                      <input
                        type="text"
                        value={prodHindiName}
                        onChange={(e) => setProdHindiName(e.target.value)}
                        placeholder="उदा. स्कॉर्पियन ओवरसाइज़्ड टी-शर्ट"
                        className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        Category*
                      </label>
                      <select
                        value={prodCategory}
                        onChange={(e) => setProdCategory(e.target.value as any)}
                        className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
                      >
                        <option value="men">Men (पुरुष / मेन्स)</option>
                        <option value="women">Women (महिलाएं / वुमेन्स)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        Sub-Category*
                      </label>
                      <select
                        value={prodSubCategory}
                        onChange={(e) => setProdSubCategory(e.target.value as any)}
                        className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
                      >
                        <option value="t-shirts">T-Shirts (टी-शर्ट्स)</option>
                        <option value="shirts">Shirts (शर्ट्स)</option>
                        <option value="jeans">Jeans (जीन्स)</option>
                        <option value="hoodies">Hoodies (हुडीज़)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        Selling Price (₹)*
                      </label>
                      <input
                        type="number"
                        required
                        value={prodPrice}
                        onChange={(e) => setProdPrice(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        Original MRP (₹)*
                      </label>
                      <input
                        type="number"
                        required
                        value={prodOriginalPrice}
                        onChange={(e) => setProdOriginalPrice(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        Image URL (Unsplash or direct image link)*
                      </label>
                      <input
                        type="url"
                        required
                        value={prodImageUrl}
                        onChange={(e) => setProdImageUrl(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        Description*
                      </label>
                      <textarea
                        rows={2}
                        required
                        value={prodDesc}
                        onChange={(e) => setProdDesc(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsEditingProduct(false)}
                      className="px-4 py-2 rounded-xl bg-neutral-800 text-xs text-neutral-300 hover:bg-neutral-700"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold"
                    >
                      Save Product
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* TAB 3: STORE & UPI SETTINGS */}
          {activeTab === 'settings' && (
            <form
              onSubmit={handleSaveSettings}
              className="bg-neutral-950 border border-neutral-800 rounded-2xl p-5 space-y-4 max-w-xl"
            >
              <div>
                <h4 className="font-bold text-white text-base">Store & Payment Setup</h4>
                <p className="text-xs text-neutral-400">
                  Manage the UPI ID where customer QR payments will be sent, and store contact numbers.
                </p>
              </div>

              <div className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Store UPI ID (VPA for QR Payment)*
                  </label>
                  <input
                    type="text"
                    required
                    value={storeUpiId}
                    onChange={(e) => setStoreUpiId(e.target.value)}
                    placeholder="e.g. yourname@okaxis, scorpion@upi, 9876543210@paytm"
                    className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-white font-mono outline-none"
                  />
                  <p className="text-[11px] text-neutral-500 mt-1">
                    Customer will scan the dynamic QR code generated with this UPI ID.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Payee Name (displayed on UPI apps)*
                  </label>
                  <input
                    type="text"
                    required
                    value={storeUpiName}
                    onChange={(e) => setStoreUpiName(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    WhatsApp Number (for order notifications)*
                  </label>
                  <input
                    type="text"
                    required
                    value={storeWhatsApp}
                    onChange={(e) => setStoreWhatsApp(e.target.value)}
                    placeholder="+919876543210"
                    className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-white font-mono outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Top Announcement Banner Text
                  </label>
                  <input
                    type="text"
                    value={storeNotice}
                    onChange={(e) => setStoreNotice(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-white outline-none"
                  />
                </div>
              </div>

              {settingsSaved && (
                <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs p-2.5 rounded-xl flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  <span>Settings updated successfully!</span>
                </div>
              )}

              <button
                type="submit"
                className="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs transition-colors cursor-pointer"
              >
                Save Settings
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
