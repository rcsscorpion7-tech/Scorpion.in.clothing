import React from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, Truck } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    removeFromCart,
    updateCartQuantity,
    cartTotal,
    cartCount,
    settings,
    openCartCheckout,
    t,
  } = useStore();

  if (!isCartOpen) return null;

  const freeShippingThreshold = settings.freeShippingAbove;
  const amountNeededForFreeShipping = Math.max(0, freeShippingThreshold - cartTotal);
  const freeShippingProgress = Math.min(100, (cartTotal / freeShippingThreshold) * 100);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={() => setIsCartOpen(false)}
        className="fixed inset-0 bg-black/75 backdrop-blur-sm transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-neutral-900 border-l border-neutral-800 text-white flex flex-col shadow-2xl">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/80">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <h3 className="font-bold text-base sm:text-lg">
                {t('Shopping Bag', 'आपकी शॉपिंग कार्ट')} ({cartCount})
              </h3>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 flex items-center justify-center text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Free Shipping Progress Indicator */}
          <div className="bg-neutral-950 p-3.5 border-b border-neutral-800 space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5 text-neutral-300">
                <Truck className="w-3.5 h-3.5 text-amber-500" />
                {amountNeededForFreeShipping > 0 ? (
                  <span>
                    Add <strong className="text-amber-400">₹{amountNeededForFreeShipping}</strong> for FREE Shipping!
                  </span>
                ) : (
                  <span className="text-emerald-400 font-semibold">
                    🎉 You have unlocked FREE Delivery!
                  </span>
                )}
              </span>
              <span className="text-[11px] text-neutral-400 font-mono">
                {Math.round(freeShippingProgress)}%
              </span>
            </div>
            <div className="w-full bg-neutral-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-amber-500 h-full transition-all duration-300 rounded-full"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
                <div className="w-16 h-16 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-500">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-base text-neutral-300">
                  {t('Your cart is currently empty', 'आपकी कार्ट खाली है')}
                </h4>
                <p className="text-xs text-neutral-400 max-w-xs">
                  {t('Browse our exclusive streetwear collection and add your favorite items.', 'हमारे नए स्कॉर्पियन कलेक्शन्स देखें और पसंदीदा कपड़े जोड़ें।')}
                </p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="mt-2 py-2 px-5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs transition-colors cursor-pointer"
                >
                  {t('Start Shopping', 'शॉपिंग शुरू करें')}
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={item.id}
                  className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 flex gap-3 items-center"
                >
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-16 h-20 object-cover rounded-lg border border-neutral-800 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-xs sm:text-sm text-white truncate">
                      {item.product.name}
                    </h4>
                    <div className="text-[11px] text-neutral-400 flex items-center gap-2 mt-0.5">
                      <span className="bg-neutral-900 border border-neutral-700 px-1.5 py-0.2 rounded text-amber-400 font-bold">
                        {item.selectedSize}
                      </span>
                      <span>{item.selectedColor.name}</span>
                    </div>
                    <div className="font-bold text-amber-400 text-sm mt-1">
                      ₹{item.product.price.toLocaleString('en-IN')}
                    </div>

                    {/* Quantity Selector */}
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-lg overflow-hidden">
                        <button
                          type="button"
                          onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                          className="px-2 py-0.5 text-xs text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
                        >
                          -
                        </button>
                        <span className="px-2 text-xs font-semibold">{item.quantity}</span>
                        <button
                          type="button"
                          onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                          className="px-2 py-0.5 text-xs text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
                        >
                          +
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => removeFromCart(item.id)}
                        className="text-neutral-500 hover:text-rose-400 p-1 transition-colors cursor-pointer ml-auto"
                        title="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Checkout Bar */}
          {cart.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-neutral-800 bg-neutral-950/90 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-neutral-400">{t('Subtotal', 'कुल रकम')}:</span>
                <span className="text-xl font-extrabold text-amber-400">
                  ₹{cartTotal.toLocaleString('en-IN')}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 text-center">
                ⚡ 100% Safe & Instant UPI QR Payment
              </p>
              <button
                type="button"
                onClick={openCartCheckout}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 transition-all cursor-pointer"
              >
                <span>{t('Proceed to Checkout (ऑर्डर करें)', 'ऑर्डर करने के लिए आगे बढ़ें')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
