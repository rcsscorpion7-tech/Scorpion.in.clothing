import React from 'react';
import { ArrowRight, Sparkles, ShieldCheck, Truck, Zap, QrCode } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const HeroBanner: React.FC = () => {
  const { setSelectedCategory, setSelectedSubCategory, t } = useStore();

  const handleShopMen = () => {
    setSelectedCategory('men');
    setSelectedSubCategory('all');
    window.scrollTo({ top: 580, behavior: 'smooth' });
  };

  const handleShopWomen = () => {
    setSelectedCategory('women');
    setSelectedSubCategory('all');
    window.scrollTo({ top: 580, behavior: 'smooth' });
  };

  return (
    <div className="relative overflow-hidden bg-neutral-950 border-b border-neutral-900">
      {/* Background Decorative Gradients & Glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 right-10 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Grid Pattern */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #ffffff 1px, transparent 0)`,
          backgroundSize: '24px 24px',
        }}
      />

      <div className="container mx-auto px-4 py-12 sm:py-16 lg:py-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Hero Text */}
          <div className="lg:col-span-7 space-y-5 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t('NEW ARRIVALS 2026 • SCORPION EDITION', 'नया कलेक्शन 2026 • स्कॉर्पियन एडिशन')}</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.08] font-heading">
              WEAR THE <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-500 to-red-500">STING.</span>
              <br />
              <span className="text-neutral-200">DEFY THE ORDINARY.</span>
            </h1>

            <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              {t(
                'Explore premium heavyweight T-Shirts, Shirts, Baggy Jeans, and Street Hoodies. Engineered with pure 100% combed cotton and raw urban edge.',
                'प्रीमियम हैवीवेट टी-शर्ट्स, शर्ट्स, बैगी जीन्स और स्ट्रीट हुडीज़ का शानदार कलेक्शन। 100% प्योर कॉटन और बेस्ट क्वालिटी।'
              )}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
              <button
                onClick={handleShopMen}
                className="w-full sm:w-auto py-3.5 px-7 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 transition-all cursor-pointer hover:scale-105"
              >
                <span>{t("Shop Men's Collection", 'मेन्स कलेक्शन देखें')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={handleShopWomen}
                className="w-full sm:w-auto py-3.5 px-7 rounded-2xl bg-neutral-900 hover:bg-neutral-800 text-white font-extrabold text-sm flex items-center justify-center gap-2 border border-neutral-800 hover:border-neutral-700 transition-all cursor-pointer hover:scale-105"
              >
                <span>{t("Shop Women's Collection", 'वुमेन्स कलेक्शन देखें')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Micro Highlights */}
            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-neutral-900/80 max-w-md mx-auto lg:mx-0">
              <div className="flex items-center gap-2 text-xs text-neutral-300">
                <QrCode className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Instant UPI QR</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-neutral-300">
                <Truck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Fast Shipping</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-neutral-300">
                <ShieldCheck className="w-4 h-4 text-sky-400 shrink-0" />
                <span>100% Pure Cotton</span>
              </div>
            </div>
          </div>

          {/* Right Dual Hero Showcase (Men & Women Cards) */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-3.5">
            {/* Men's Card */}
            <div
              onClick={handleShopMen}
              className="group relative rounded-2xl overflow-hidden aspect-[4/5] bg-neutral-900 border border-neutral-800 hover:border-amber-500/50 cursor-pointer shadow-2xl transition-transform hover:-translate-y-1"
            >
              <img
                src="https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=800&auto=format&fit=crop&q=80"
                alt="Men's Collection"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
              <div className="absolute bottom-3 left-3 right-3">
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 bg-black/60 px-2 py-0.5 rounded backdrop-blur-sm">
                  COLLECTION
                </span>
                <h3 className="text-base sm:text-lg font-black text-white mt-1">
                  MEN'S DROP
                </h3>
                <p className="text-[11px] text-neutral-300">Acid Tees, Denim & Hoodies</p>
              </div>
            </div>

            {/* Women's Card */}
            <div
              onClick={handleShopWomen}
              className="group relative rounded-2xl overflow-hidden aspect-[4/5] bg-neutral-900 border border-neutral-800 hover:border-amber-500/50 cursor-pointer shadow-2xl transition-transform hover:-translate-y-1"
            >
              <img
                src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&auto=format&fit=crop&q=80"
                alt="Women's Collection"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
              <div className="absolute bottom-3 left-3 right-3">
                <span className="text-[10px] font-black uppercase tracking-wider text-rose-400 bg-black/60 px-2 py-0.5 rounded backdrop-blur-sm">
                  COLLECTION
                </span>
                <h3 className="text-base sm:text-lg font-black text-white mt-1">
                  WOMEN'S DROP
                </h3>
                <p className="text-[11px] text-neutral-300">Cropped Hoodies & Baggy Cargo</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
