import React, { useState } from 'react';
import {
  X,
  Star,
  ShieldCheck,
  Truck,
  RotateCcw,
  Zap,
  ShoppingBag,
  Check,
  Ruler,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { ProductSize, ProductColor } from '../types';

export const ProductModal: React.FC = () => {
  const {
    selectedProductForModal,
    setSelectedProductForModal,
    openDirectCheckout,
    addToCart,
    t,
    language,
  } = useStore();

  const product = selectedProductForModal;

  const [selectedSize, setSelectedSize] = useState<ProductSize>(
    product?.sizes[0] || 'L'
  );
  const [selectedColor, setSelectedColor] = useState<ProductColor>(
    product?.colors[0] || { name: 'Standard', hex: '#000000' }
  );
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedNotice, setAddedNotice] = useState(false);
  const [pincodeCheck, setPincodeCheck] = useState('');
  const [deliveryMessage, setDeliveryMessage] = useState<string | null>(null);
  const [showSizeChart, setShowSizeChart] = useState(false);

  if (!product) return null;

  const handleAddToCart = () => {
    addToCart(product, selectedSize, selectedColor, quantity);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2000);
  };

  const handleOrderNow = () => {
    openDirectCheckout(product, selectedSize, selectedColor, quantity);
    setSelectedProductForModal(null);
  };

  const handleCheckPincode = (e: React.FormEvent) => {
    e.preventDefault();
    if (pincodeCheck.length === 6) {
      setDeliveryMessage(`✓ Available for delivery to ${pincodeCheck}! Estimated 2-4 days.`);
    } else {
      setDeliveryMessage('Please enter a valid 6-digit PIN code.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-hidden flex flex-col shadow-2xl relative my-auto">
        {/* Header bar */}
        <div className="px-6 py-3.5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/70 sticky top-0 z-20">
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="uppercase text-amber-500 font-bold">{product.category}</span>
            <span>/</span>
            <span className="capitalize">{product.subCategory}</span>
          </div>
          <button
            onClick={() => setSelectedProductForModal(null)}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 flex items-center justify-center text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-5 sm:p-8 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Images Column */}
          <div className="space-y-4">
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-neutral-950 border border-neutral-800 group">
              <img
                src={product.images[activeImageIndex] || product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              {product.badge && (
                <span className="absolute top-3 left-3 px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-full bg-amber-500 text-black shadow-lg">
                  {product.badge}
                </span>
              )}
              <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-full text-xs font-semibold text-emerald-400 border border-emerald-500/30">
                {product.discountPercent}% OFF
              </div>
            </div>

            {/* Thumbnail selector */}
            {product.images.length > 1 && (
              <div className="flex gap-2">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                      activeImageIndex === idx ? 'border-amber-500 scale-105' : 'border-neutral-800 opacity-60'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Feature list */}
            <div className="bg-neutral-950/70 border border-neutral-800 rounded-xl p-4 space-y-2">
              <h5 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                Product Highlights:
              </h5>
              <div className="grid grid-cols-2 gap-2 text-xs text-neutral-300">
                {product.features.map((feat, i) => (
                  <div key={i} className="flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Details Column */}
          <div className="space-y-5">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <div className="flex items-center text-amber-400 text-xs font-bold gap-1 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  <span>{product.rating}</span>
                </div>
                <span className="text-xs text-neutral-400">({product.reviewsCount} customer reviews)</span>
                <span className="text-xs text-emerald-400 ml-auto font-medium">In Stock ({product.stockCount} left)</span>
              </div>

              <h2 className="text-xl sm:text-2xl font-bold text-white leading-snug">
                {language === 'hi' && product.hindiName ? product.hindiName : product.name}
              </h2>
              {language === 'hi' && (
                <p className="text-xs text-neutral-400 mt-0.5">{product.name}</p>
              )}
            </div>

            {/* Pricing */}
            <div className="flex items-baseline gap-3 border-y border-neutral-800/80 py-3">
              <span className="text-3xl font-extrabold text-white">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
              <span className="text-base text-neutral-500 line-through">
                ₹{product.originalPrice.toLocaleString('en-IN')}
              </span>
              <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/30">
                Save ₹{(product.originalPrice - product.price).toLocaleString('en-IN')}
              </span>
            </div>

            {/* Description */}
            <p className="text-sm text-neutral-300 leading-relaxed">
              {language === 'hi' && product.hindiDescription ? product.hindiDescription : product.description}
            </p>

            {/* Color Selection */}
            <div>
              <div className="text-xs font-semibold text-neutral-300 mb-2 flex items-center justify-between">
                <span>Color: <strong className="text-white">{selectedColor.name}</strong></span>
              </div>
              <div className="flex gap-2.5">
                {product.colors.map((c, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedColor(c)}
                    className={`w-8 h-8 rounded-full border-2 transition-all flex items-center justify-center cursor-pointer ${
                      selectedColor.name === c.name
                        ? 'border-amber-400 scale-110 shadow-lg shadow-amber-500/20'
                        : 'border-neutral-700 hover:scale-105'
                    }`}
                    style={{ backgroundColor: c.hex }}
                    title={c.name}
                  >
                    {selectedColor.name === c.name && (
                      <Check className={`w-4 h-4 ${c.hex === '#ffffff' || c.hex === '#e2e8f0' ? 'text-black' : 'text-white'}`} />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Size Selection */}
            <div>
              <div className="text-xs font-semibold text-neutral-300 mb-2 flex items-center justify-between">
                <span>Size: <strong className="text-white">{selectedSize}</strong></span>
                <button
                  type="button"
                  onClick={() => setShowSizeChart(!showSizeChart)}
                  className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                >
                  <Ruler className="w-3.5 h-3.5" />
                  <span>Size Chart</span>
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSelectedSize(s)}
                    className={`w-12 h-10 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                      selectedSize === s
                        ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20'
                        : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>

              {/* Size Chart Toggle */}
              {showSizeChart && (
                <div className="mt-2.5 p-3 rounded-xl bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-300">
                  <div className="font-semibold text-white mb-1.5">Size Measurement Guide (Inches):</div>
                  <div className="grid grid-cols-4 gap-1 text-center border-t border-neutral-800 pt-1.5 text-neutral-400">
                    <div>Size: S (38")</div>
                    <div>Size: M (40")</div>
                    <div>Size: L (42")</div>
                    <div>Size: XL (44")</div>
                  </div>
                </div>
              )}
            </div>

            {/* Quantity */}
            <div className="flex items-center gap-4">
              <span className="text-xs font-semibold text-neutral-300">Quantity:</span>
              <div className="flex items-center bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-1.5 text-neutral-300 hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  -
                </button>
                <span className="px-3 py-1.5 text-sm font-semibold text-white">{quantity}</span>
                <button
                  type="button"
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-1.5 text-neutral-300 hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons: "Order Now" (Highlight) & "Add to Cart" */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={handleOrderNow}
                className="py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 transition-all cursor-pointer transform hover:-translate-y-0.5"
              >
                <Zap className="w-4 h-4 fill-black" />
                <span>{t('Order Now (अभी ऑर्डर करें)', 'अभी ऑर्डर करें (Order Now)')}</span>
              </button>

              <button
                type="button"
                onClick={handleAddToCart}
                className="py-3.5 px-6 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-sm flex items-center justify-center gap-2 border border-neutral-700 transition-colors cursor-pointer"
              >
                {addedNotice ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400">Added to Cart!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>{t('Add to Cart', 'कार्ट में डालें')}</span>
                  </>
                )}
              </button>
            </div>

            {/* Pincode delivery check */}
            <div className="border-t border-neutral-800/80 pt-4">
              <form onSubmit={handleCheckPincode} className="flex gap-2">
                <input
                  type="text"
                  maxLength={6}
                  value={pincodeCheck}
                  onChange={(e) => setPincodeCheck(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter 6-digit PIN code"
                  className="flex-1 bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-500 outline-none"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold transition-colors cursor-pointer"
                >
                  Check
                </button>
              </form>
              {deliveryMessage && (
                <p className="text-[11px] text-amber-400 mt-1.5">{deliveryMessage}</p>
              )}
            </div>

            {/* Badges */}
            <div className="grid grid-cols-3 gap-2 pt-1 text-center">
              <div className="p-2.5 rounded-xl bg-neutral-950/60 border border-neutral-800/60 text-[11px] text-neutral-400 flex flex-col items-center gap-1">
                <Truck className="w-4 h-4 text-amber-400" />
                <span>Express Delivery</span>
              </div>
              <div className="p-2.5 rounded-xl bg-neutral-950/60 border border-neutral-800/60 text-[11px] text-neutral-400 flex flex-col items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>100% Cotton & Quality</span>
              </div>
              <div className="p-2.5 rounded-xl bg-neutral-950/60 border border-neutral-800/60 text-[11px] text-neutral-400 flex flex-col items-center gap-1">
                <RotateCcw className="w-4 h-4 text-sky-400" />
                <span>7-Day Easy Exchange</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
