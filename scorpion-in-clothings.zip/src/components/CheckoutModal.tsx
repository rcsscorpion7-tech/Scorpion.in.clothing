import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  X,
  ShoppingBag,
  CheckCircle2,
  Phone,
  MapPin,
  ArrowRight,
  ShieldCheck,
  Printer,
  MessageCircle,
  Truck,
  CreditCard,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { UpiQrSection } from './UpiQrSection';
import { INDIAN_STATES } from '../data/initialProducts';
import { CartItem, Order } from '../types';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    directBuyItem,
    cart,
    cartTotal,
    settings,
    createOrder,
    t,
    language,
  } = useStore();

  // Form Fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('Delhi NCR');
  const [pincode, setPincode] = useState('');
  const [landmark, setLandmark] = useState('');
  const [upiTxnId, setUpiTxnId] = useState('');
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);

  // Status
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [formError, setFormError] = useState('');

  if (!isCheckoutOpen) return null;

  // Determine items being purchased: either single item from "Order Now" or full cart
  const itemsToPurchase: CartItem[] = directBuyItem
    ? [
        {
          id: `${directBuyItem.product.id}-${directBuyItem.selectedSize}-${directBuyItem.selectedColor.name}`,
          product: directBuyItem.product,
          selectedSize: directBuyItem.selectedSize,
          selectedColor: directBuyItem.selectedColor,
          quantity: directBuyItem.quantity,
        },
      ]
    : cart;

  if (itemsToPurchase.length === 0 && !completedOrder) {
    return (
      <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-md w-full p-6 text-center space-y-4">
          <ShoppingBag className="w-12 h-12 text-neutral-600 mx-auto" />
          <h3 className="text-lg font-bold text-white">
            {t('Your cart is empty', 'आपकी कार्ट खाली है')}
          </h3>
          <p className="text-sm text-neutral-400">
            {t(
              'Please select a product and click "Order Now" to place an order.',
              'कृपया किसी प्रोडक्ट पर जाएं और "Order Now" पर क्लिक करें।'
            )}
          </p>
          <button
            onClick={() => setIsCheckoutOpen(false)}
            className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-semibold text-sm transition-colors cursor-pointer"
          >
            {t('Continue Shopping', 'शॉपिंग जारी रखें')}
          </button>
        </div>
      </div>
    );
  }

  // Cost calculations
  const subtotal = directBuyItem
    ? directBuyItem.product.price * directBuyItem.quantity
    : cartTotal;

  const isFreeDelivery = subtotal >= settings.freeShippingAbove;
  const shippingFee = isFreeDelivery ? 0 : 79;
  const totalAmount = subtotal + shippingFee;

  const previewTempId = `SCP-${Math.floor(10000 + Math.random() * 90000)}`;

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    // Validations
    if (!name.trim()) {
      setFormError(t('Please enter your full name', 'कृपया अपना पूरा नाम लिखें'));
      return;
    }

    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setFormError(t('Please enter a valid 10-digit mobile number', 'कृपया 10 अंकों का सही मोबाइल नंबर दर्ज करें'));
      return;
    }

    if (!address.trim() || address.length < 5) {
      setFormError(t('Please provide your full delivery address', 'कृपया पूरा डिलीवरी पता (मकान नं., गली आदि) लिखें'));
      return;
    }

    if (!city.trim()) {
      setFormError(t('Please enter your city', 'कृपया अपने शहर का नाम लिखें'));
      return;
    }

    const cleanPin = pincode.replace(/\D/g, '');
    if (cleanPin.length !== 6) {
      setFormError(t('Please enter a valid 6-digit PIN code', 'कृपया 6 अंकों का पिन कोड दर्ज करें'));
      return;
    }

    if (!upiTxnId.trim()) {
      setFormError(
        t(
          'Please enter the UPI Reference ID / UTR number after scanning QR',
          'कृपया QR कोड स्कैन करके पेमेंट करने के बाद UTR/ट्रांजैक्शन नंबर दर्ज करें'
        )
      );
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const newOrder = createOrder({
        items: itemsToPurchase,
        subtotal,
        shipping: shippingFee,
        discount: 0,
        totalAmount,
        customer: {
          name: name.trim(),
          phone: cleanPhone,
          address: address.trim(),
          city: city.trim(),
          state,
          pincode: cleanPin,
          landmark: landmark.trim() || undefined,
        },
        paymentMethod: 'upi',
        paymentStatus: 'verified',
        orderStatus: 'Placed',
        upiTxnId: upiTxnId.trim(),
        notes: screenshotPreview ? 'Screenshot proof attached' : undefined,
      });

      setCompletedOrder(newOrder);
      setIsSubmitting(false);

      // Fire celebratory confetti!
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }, 600);
  };

  const handleClose = () => {
    setIsCheckoutOpen(false);
    setCompletedOrder(null);
    setFormError('');
  };

  // WhatsApp link generator
  const getWhatsAppOrderUrl = (order: Order) => {
    const itemNames = order.items
      .map((i) => `${i.product.name} (Size: ${i.selectedSize}, Qty: ${i.quantity})`)
      .join(', ');

    const text = `*New Order Placed at Scorpion In clothings!* 🔥\n\n*Order ID:* ${order.id}\n*Customer:* ${order.customer.name}\n*Mobile:* ${order.customer.phone}\n*Address:* ${order.customer.address}, ${order.customer.city}, ${order.customer.state} - ${order.customer.pincode}\n\n*Items:* ${itemNames}\n*Total Amount:* ₹${order.totalAmount}\n*Payment Method:* ${order.paymentMethod.toUpperCase()}${order.upiTxnId ? `\n*UPI UTR / Ref:* ${order.upiTxnId}` : ''}\n\nPlease confirm my order shipment. Thank you!`;

    const cleanNumber = settings.whatsappNumber.replace(/\D/g, '');
    return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(text)}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-hidden flex flex-col shadow-2xl relative my-auto">
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60 sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 font-brand font-bold text-lg">
              🦂
            </div>
            <div>
              <h3 className="font-bold text-white text-base sm:text-lg">
                {completedOrder
                  ? t('Order Placed Successfully! 🎉', 'ऑर्डर सफलतापूर्वक स्वीकार कर लिया गया! 🎉')
                  : t('Order Now - Checkout', 'ऑर्डर फॉर्म - डिलीवरी व पेमेंट')}
              </h3>
              <p className="text-xs text-neutral-400">Scorpion In clothings • Fast Delivery</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 flex items-center justify-center text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          {completedOrder ? (
            /* --- ORDER SUCCESS CONFIRMATION SCREEN --- */
            <div className="space-y-6 text-center">
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 border-2 border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto animate-bounce">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div className="space-y-1">
                <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400 bg-emerald-950/60 px-3 py-1 rounded-full border border-emerald-800">
                  {t('Confirmed Order', 'कन्फर्म्ड ऑर्डर')}
                </span>
                <h4 className="text-2xl font-extrabold text-white">
                  {t('Thank You,', 'धन्यवाद,')} {completedOrder.customer.name}!
                </h4>
                <p className="text-sm text-neutral-400">
                  {t(
                    'Your order has been recorded. Our team will pack and ship it shortly.',
                    'आपका ऑर्डर सफलतापूर्वक दर्ज कर लिया गया है। जल्द ही इसे पैक करके डिस्पैच किया जाएगा।'
                  )}
                </p>
              </div>

              {/* Order Receipt Box */}
              <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-5 text-left space-y-4">
                <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                  <div>
                    <div className="text-xs text-neutral-500">Order ID</div>
                    <div className="text-lg font-mono font-bold text-amber-400">
                      {completedOrder.id}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-neutral-500">Total Amount</div>
                    <div className="text-lg font-bold text-white">
                      ₹{completedOrder.totalAmount.toLocaleString('en-IN')}
                    </div>
                  </div>
                </div>

                {/* Items List */}
                <div className="space-y-2">
                  <div className="text-xs font-semibold text-neutral-400 uppercase">
                    Ordered Items:
                  </div>
                  {completedOrder.items.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between text-xs bg-neutral-900/60 p-2.5 rounded-lg border border-neutral-800/60"
                    >
                      <div className="flex items-center gap-2">
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-9 h-9 object-cover rounded"
                        />
                        <div>
                          <div className="font-medium text-white truncate max-w-[200px] sm:max-w-[300px]">
                            {item.product.name}
                          </div>
                          <div className="text-neutral-400 text-[11px]">
                            Size: <span className="text-amber-400">{item.selectedSize}</span> | Qty:{' '}
                            {item.quantity}
                          </div>
                        </div>
                      </div>
                      <div className="font-semibold text-neutral-200">
                        ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Delivery Address */}
                <div className="bg-neutral-900/40 p-3 rounded-lg border border-neutral-800/60 text-xs space-y-1">
                  <div className="font-semibold text-neutral-300 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-amber-500" />
                    <span>Delivery Address (डिलीवरी पता):</span>
                  </div>
                  <p className="text-neutral-400">
                    {completedOrder.customer.address}, {completedOrder.customer.city},{' '}
                    {completedOrder.customer.state} - {completedOrder.customer.pincode}
                  </p>
                  <p className="text-neutral-400 flex items-center gap-1 pt-1">
                    <Phone className="w-3 h-3 text-neutral-500" /> Mobile: +91 {completedOrder.customer.phone}
                  </p>
                </div>

                {/* Payment info */}
                <div className="flex items-center justify-between text-xs text-neutral-400 pt-1">
                  <span>
                    Payment: <strong className="text-white">{completedOrder.paymentMethod.toUpperCase()}</strong>
                  </span>
                  {completedOrder.upiTxnId && (
                    <span className="font-mono text-[11px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">
                      UTR: {completedOrder.upiTxnId}
                    </span>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <a
                  href={getWhatsAppOrderUrl(completedOrder)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-all shadow-lg shadow-emerald-950/40"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{t('Send Details on WhatsApp', 'व्हाट्सएप पर ऑर्डर भेजें')}</span>
                </a>

                <button
                  onClick={() => window.print()}
                  className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-sm transition-colors border border-neutral-700 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>{t('Print / Save Receipt', 'रसीद प्रिंट / सेव करें')}</span>
                </button>
              </div>

              <button
                onClick={handleClose}
                className="w-full py-2.5 text-sm text-neutral-400 hover:text-white transition-colors cursor-pointer"
              >
                ← {t('Back to Store', 'दुकान पर वापस जाएं')}
              </button>
            </div>
          ) : (
            /* --- CHECKOUT FORM --- */
            <form onSubmit={handleSubmitOrder} className="space-y-6">
              {/* Product summary card */}
              <div className="bg-neutral-950 rounded-2xl p-4 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-neutral-400 uppercase tracking-wider">
                  <span>{t('Selected Product(s)', 'चुना हुआ सामान')} ({itemsToPurchase.length})</span>
                  <span className="text-amber-500">Scorpion In clothings</span>
                </div>

                <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                  {itemsToPurchase.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-3 bg-neutral-900/60 p-2.5 rounded-xl border border-neutral-800/80"
                    >
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        className="w-12 h-12 object-cover rounded-lg border border-neutral-700 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-white text-xs sm:text-sm truncate">
                          {language === 'hi' && item.product.hindiName
                            ? item.product.hindiName
                            : item.product.name}
                        </div>
                        <div className="text-[11px] text-neutral-400 flex items-center gap-2 mt-0.5">
                          <span className="bg-neutral-800 px-1.5 py-0.5 rounded text-amber-400 font-semibold">
                            Size: {item.selectedSize}
                          </span>
                          <span>Color: {item.selectedColor.name}</span>
                          <span>Qty: {item.quantity}</span>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="font-bold text-white text-sm">
                          ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                        </div>
                        <div className="text-[11px] text-neutral-500 line-through">
                          ₹{(item.product.originalPrice * item.quantity).toLocaleString('en-IN')}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Customer Details Section */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-neutral-800 pb-2">
                  <MapPin className="w-4 h-4 text-amber-500" />
                  <h4 className="font-bold text-white text-sm sm:text-base">
                    {t('Customer & Delivery Details', 'ग्राहक और डिलीवरी की जानकारी')}
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('Full Name (कस्टमर का नाम)*', 'कस्टमर का पूरा नाम*')}
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="उदा. राहुल शर्मा / Rahul Sharma"
                      className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('Mobile Number (मोबाइल नंबर)*', 'मोबाइल नंबर (10 अंक)*')}
                    </label>
                    <div className="relative flex items-center">
                      <span className="absolute left-3 text-xs text-neutral-500 font-medium">
                        +91
                      </span>
                      <input
                        type="tel"
                        required
                        maxLength={10}
                        value={phone}
                        onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                        placeholder="9876543210"
                        className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl pl-11 pr-3.5 py-2.5 text-sm text-white placeholder-neutral-500 outline-none transition-colors font-mono"
                      />
                    </div>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('Full Address (मकान नंबर, गली, मोहल्ला / एरिया)*', 'फुल एड्रेस (मकान नंबर, सड़क, एरिया)*')}
                    </label>
                    <textarea
                      required
                      rows={2}
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="उदा. फ्लैट 302, राज रेजीडेंसी, नियर मॉल, एमजी रोड"
                      className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 outline-none transition-colors resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('Landmark (पहचान / लैंडमार्क - वैकल्पिक)', 'पहचान / लैंडमार्क (वैकल्पिक)')}
                    </label>
                    <input
                      type="text"
                      value={landmark}
                      onChange={(e) => setLandmark(e.target.value)}
                      placeholder="उदा. मंदिर के पास / पेट्रोल पंप के सामने"
                      className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('City (शहर)*', 'शहर का नाम*')}
                    </label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="उदा. जयपुर / दिल्ली / मुंबई"
                      className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('State (राज्य)*', 'राज्य (State)*')}
                    </label>
                    <select
                      value={state}
                      onChange={(e) => setState(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl px-3 py-2.5 text-sm text-white outline-none transition-colors"
                    >
                      {INDIAN_STATES.map((st) => (
                        <option key={st} value={st} className="bg-neutral-900 text-white">
                          {st}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('PIN Code (पिन कोड)*', 'पिन कोड (6 डिजिट)*')}
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))}
                      placeholder="302001"
                      className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 outline-none transition-colors font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Direct UPI QR Payment Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-amber-500" />
                    <h4 className="font-bold text-white text-sm sm:text-base">
                      {t('UPI QR Payment (Prepaid)', 'UPI QR कोड पेमेंट (प्रीपेड)')}
                    </h4>
                  </div>
                  <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2.5 py-0.5 rounded-full">
                    100% SAFE & FAST
                  </span>
                </div>

                {/* Dynamic UPI QR Section */}
                <UpiQrSection
                  amount={totalAmount}
                  orderIdPreview={previewTempId}
                  upiTxnId={upiTxnId}
                  setUpiTxnId={setUpiTxnId}
                  screenshotPreview={screenshotPreview}
                  setScreenshotPreview={setScreenshotPreview}
                />
              </div>

              {/* Price Breakdown */}
              <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-4 space-y-2 text-xs">
                <div className="flex justify-between text-neutral-400">
                  <span>Subtotal ({itemsToPurchase.length} items)</span>
                  <span className="text-neutral-200">₹{subtotal.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span className="flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5" />
                    Delivery Charges
                  </span>
                  <span className={isFreeDelivery ? 'text-emerald-400 font-semibold' : 'text-neutral-200'}>
                    {isFreeDelivery ? 'FREE (मुफ़्त डिलीवरी)' : `₹${shippingFee}`}
                  </span>
                </div>
                <div className="border-t border-neutral-800 pt-2 flex justify-between text-sm font-bold text-white">
                  <span>Grand Total (कुल राशि)</span>
                  <span className="text-amber-400 text-base">₹{totalAmount.toLocaleString('en-IN')}</span>
                </div>
              </div>

              {/* Error message */}
              {formError && (
                <div className="bg-rose-500/10 border border-rose-500/40 text-rose-300 text-xs p-3 rounded-xl">
                  {formError}
                </div>
              )}

              {/* Submit Button */}
              <div className="space-y-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-extrabold text-base tracking-wide flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>{t('Confirm & Place Order Now', 'ऑर्डर कन्फर्म करें (Place Order)')}</span>
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </button>
                <div className="flex items-center justify-center gap-2 text-[11px] text-neutral-500">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  <span>100% Genuine Products • 7 Days Hassle-Free Exchange</span>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
