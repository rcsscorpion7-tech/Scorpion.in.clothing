import React from 'react';
import { Phone, MessageCircle, Mail, MapPin, ShieldCheck, Heart, QrCode } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const Footer: React.FC = () => {
  const { settings, setIsAdminOpen, setIsTrackOrderOpen, t } = useStore();

  return (
    <footer className="bg-neutral-950 border-t border-neutral-900 text-neutral-400 text-xs">
      {/* Top Value Propositions */}
      <div className="border-b border-neutral-900/80 py-8">
        <div className="container mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="space-y-1">
            <div className="text-amber-500 font-bold text-sm">🔥 100% Cotton Streetwear</div>
            <p className="text-neutral-500 text-[11px]">Heavy GSM fabric pre-shrunk & bio-washed.</p>
          </div>
          <div className="space-y-1">
            <div className="text-emerald-400 font-bold text-sm">⚡ Instant UPI QR Payment</div>
            <p className="text-neutral-500 text-[11px]">Zero convenience fee with direct UPI apps.</p>
          </div>
          <div className="space-y-1">
            <div className="text-sky-400 font-bold text-sm">📦 Pan-India Express Delivery</div>
            <p className="text-neutral-500 text-[11px]">Delivered right to your doorstep in 3-5 days.</p>
          </div>
          <div className="space-y-1">
            <div className="text-rose-400 font-bold text-sm">🔄 Easy 7-Day Exchange</div>
            <p className="text-neutral-500 text-[11px]">Hassle-free size and product exchanges.</p>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="container mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand Column */}
        <div className="space-y-3 md:col-span-1">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center text-black font-extrabold text-lg">
              🦂
            </div>
            <div>
              <span className="font-brand font-black text-lg text-white tracking-wider uppercase block leading-none">
                Scorpion
              </span>
              <span className="text-[10px] uppercase tracking-[0.2em] text-amber-500 font-bold block">
                In clothings
              </span>
            </div>
          </div>
          <p className="text-neutral-400 text-xs leading-relaxed">
            {settings.tagline}. High aesthetic apparel designed for raw individuality and urban culture across India.
          </p>
          <div className="text-[11px] text-neutral-500 pt-1">
            Accepting 100% secure payments via BHIM, GPay, PhonePe, and Paytm UPI QR.
          </div>
        </div>

        {/* Quick Links */}
        <div className="space-y-2.5">
          <h4 className="font-bold text-white text-sm uppercase tracking-wider">Quick Links</h4>
          <ul className="space-y-1.5 text-neutral-400">
            <li>
              <button
                onClick={() => setIsTrackOrderOpen(true)}
                className="hover:text-amber-400 transition-colors cursor-pointer"
              >
                Track Your Order (ऑर्डर ट्रैक करें)
              </button>
            </li>
            <li>
              <span className="text-neutral-500">Men's Oversized Tees & Hoodies</span>
            </li>
            <li>
              <span className="text-neutral-500">Women's Streetwear & Denim</span>
            </li>
            <li>
              <span className="text-neutral-500">Size & Measurement Chart</span>
            </li>
            <li>
              <button
                onClick={() => setIsAdminOpen(true)}
                className="text-amber-500 hover:text-amber-400 font-semibold transition-colors cursor-pointer"
              >
                Admin Management Portal 🔐
              </button>
            </li>
          </ul>
        </div>

        {/* Customer Support */}
        <div className="space-y-2.5">
          <h4 className="font-bold text-white text-sm uppercase tracking-wider">Help & Contact</h4>
          <div className="space-y-2">
            <a
              href={`tel:${settings.contactPhone}`}
              className="flex items-center gap-2 text-neutral-300 hover:text-amber-400 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-amber-500" />
              <span>{settings.contactPhone}</span>
            </a>
            <a
              href={`https://wa.me/${settings.whatsappNumber.replace(/\D/g, '')}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 text-neutral-300 hover:text-emerald-400 transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-500" />
              <span>WhatsApp: {settings.whatsappNumber}</span>
            </a>
            <div className="flex items-center gap-2 text-neutral-400">
              <Mail className="w-3.5 h-3.5 text-neutral-500" />
              <span>{settings.supportEmail}</span>
            </div>
            <div className="flex items-center gap-2 text-neutral-400">
              <QrCode className="w-3.5 h-3.5 text-amber-500" />
              <span>UPI: {settings.upiId}</span>
            </div>
          </div>
        </div>

        {/* Delivery across India */}
        <div className="space-y-2.5">
          <h4 className="font-bold text-white text-sm uppercase tracking-wider">Fast Delivery</h4>
          <p className="text-neutral-400 text-xs">
            We deliver to all major pin codes across India including Delhi NCR, Mumbai, Bangalore, Jaipur, Lucknow, Kolkata, Hyderabad, Ahmedabad, and more.
          </p>
          <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300">
            <span className="text-amber-400 font-semibold">Free Delivery</span> on prepaid orders above ₹{settings.freeShippingAbove}!
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-neutral-900 py-4 bg-black/60">
        <div className="container mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-neutral-500 text-[11px]">
          <div>
            © {new Date().getFullYear()} Scorpion In clothings. All rights reserved.
          </div>
          <div className="flex items-center gap-3">
            <span>Made with passion for Indian Streetwear</span>
            <span>•</span>
            <button
              onClick={() => setIsAdminOpen(true)}
              className="text-neutral-400 hover:text-amber-400 underline cursor-pointer"
            >
              Admin Login
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
