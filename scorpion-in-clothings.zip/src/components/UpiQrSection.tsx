import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Copy, Check, Smartphone, ShieldCheck, QrCode, AlertCircle, Upload, Image as ImageIcon } from 'lucide-react';
import { useStore } from '../context/StoreContext';

interface UpiQrSectionProps {
  amount: number;
  orderIdPreview: string;
  upiTxnId: string;
  setUpiTxnId: (val: string) => void;
  screenshotPreview: string | null;
  setScreenshotPreview: (val: string | null) => void;
}

export const UpiQrSection: React.FC<UpiQrSectionProps> = ({
  amount,
  orderIdPreview,
  upiTxnId,
  setUpiTxnId,
  screenshotPreview,
  setScreenshotPreview,
}) => {
  const { settings, t } = useStore();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Standard UPI URI format
  const upiUrl = `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(
    settings.upiPayeeName
  )}&am=${amount.toFixed(2)}&cu=INR&tn=${encodeURIComponent(`Order ${orderIdPreview} Scorpion Clothings`)}`;

  useEffect(() => {
    if (canvasRef.current) {
      QRCode.toCanvas(
        canvasRef.current,
        upiUrl,
        {
          width: 220,
          margin: 1,
          color: {
            dark: '#000000',
            light: '#ffffff',
          },
        },
        (error) => {
          if (error) console.error('Error generating QR:', error);
        }
      );
    }
  }, [upiUrl]);

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(settings.upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500">
            <QrCode className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-semibold text-white text-base">
              {t('Instant UPI QR Payment', 'तुरंत UPI QR कोड से पेमेंट')}
            </h4>
            <p className="text-xs text-neutral-400">
              GPay, PhonePe, Paytm, BHIM या किसी भी UPI ऐप से स्कैन करें
            </p>
          </div>
        </div>
        <div className="text-right">
          <span className="text-xs text-neutral-400">Total Payable</span>
          <div className="text-lg font-bold text-amber-400">₹{amount.toLocaleString('en-IN')}</div>
        </div>
      </div>

      {/* QR Code Container */}
      <div className="flex flex-col md:flex-row items-center justify-center gap-6 bg-neutral-950 p-4 rounded-xl border border-neutral-800/80">
        <div className="relative p-3 bg-white rounded-xl shadow-xl flex flex-col items-center">
          <canvas ref={canvasRef} className="rounded" />
          <div className="mt-2 flex items-center gap-1.5 text-[11px] font-bold text-neutral-800">
            <span className="text-neutral-500">SCAN & PAY WITH ANY UPI APP</span>
          </div>
        </div>

        {/* UPI Details & Mobile Deep Links */}
        <div className="flex-1 w-full space-y-3">
          <div className="bg-neutral-900/90 rounded-lg p-3 border border-neutral-800">
            <div className="text-xs text-neutral-400 mb-1">
              {t('Official UPI ID / वीपीए', 'ऑफिशियल UPI आईडी')}:
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="font-mono text-sm text-amber-400 font-semibold truncate">
                {settings.upiId}
              </span>
              <button
                type="button"
                onClick={handleCopyUpi}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <div className="text-[11px] text-neutral-400 mt-1">
              Payee: <span className="text-neutral-200">{settings.upiPayeeName}</span>
            </div>
          </div>

          {/* Quick Pay on Mobile Button */}
          <div className="space-y-1.5">
            <a
              href={upiUrl}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs sm:text-sm transition-all shadow-lg shadow-emerald-950/40"
            >
              <Smartphone className="w-4 h-4" />
              <span>{t('Click To Pay Directly In UPI App', 'मोबाइल पर सीधे UPI ऐप खोलें')}</span>
            </a>
            <p className="text-[11px] text-center text-neutral-500">
              (Works directly on mobile with GPay, PhonePe, Paytm, CRED)
            </p>
          </div>
        </div>
      </div>

      {/* Transaction ID / UTR verification field */}
      <div className="space-y-3 pt-2">
        <div>
          <label className="block text-xs font-semibold text-neutral-200 mb-1.5">
            {t('Enter 12-Digit UPI Ref / UTR / Transaction No.*', 'पेमेंट के बाद 12-अंकों का UTR / ट्रांजैक्शन नंबर डालें*')}
          </label>
          <div className="relative">
            <input
              type="text"
              required
              value={upiTxnId}
              onChange={(e) => setUpiTxnId(e.target.value)}
              placeholder="उदा. 428190348219 या UPI-xxxx"
              className="w-full bg-neutral-950 border border-neutral-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 outline-none transition-all font-mono"
            />
          </div>
          <p className="text-[11px] text-neutral-400 mt-1 flex items-center gap-1">
            <AlertCircle className="w-3 h-3 text-amber-500 shrink-0" />
            <span>पेमेंट करने के बाद आपके GPay/PhonePe/Paytm में UTR/UPI Ref no. दिखाई देगा।</span>
          </p>
        </div>

        {/* Optional Screenshot proof upload */}
        <div className="border border-dashed border-neutral-800 rounded-xl p-3 bg-neutral-950/60 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-neutral-800 flex items-center justify-center text-neutral-400">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-medium text-neutral-300">
                {t('Payment Screenshot (Optional)', 'पेमेंट का स्क्रीनशॉट (वैकल्पिक)')}
              </div>
              <div className="text-[11px] text-neutral-500">
                {screenshotPreview ? 'स्क्रीनशॉट सेलेक्ट हो गया है ✓' : 'तेज कन्फर्मेशन के लिए रसीद अपलोड करें'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {screenshotPreview && (
              <img
                src={screenshotPreview}
                alt="Screenshot preview"
                className="w-10 h-10 object-cover rounded border border-neutral-700"
              />
            )}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 text-xs rounded-lg border border-neutral-700 hover:border-neutral-600 bg-neutral-800 text-neutral-200 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>{screenshotPreview ? 'बदलें' : 'अपलोड करें'}</span>
            </button>
          </div>
        </div>

        {/* Security badge */}
        <div className="flex items-center justify-center gap-2 text-xs text-neutral-400 pt-1">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>100% सुरक्षित और डायरेक्ट मर्चेंट वेरिफिकेशन • Scorpion Clothings</span>
        </div>
      </div>
    </div>
  );
};
