import React, { useState } from 'react';
import { X, Search, Package, MapPin, Calendar, Clock, CheckCircle, Truck, AlertCircle } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Order } from '../types';

export const TrackOrderModal: React.FC = () => {
  const { isTrackOrderOpen, setIsTrackOrderOpen, orders, t } = useStore();
  const [query, setQuery] = useState('');
  const [searched, setSearched] = useState(false);
  const [matchedOrders, setMatchedOrders] = useState<Order[]>([]);

  if (!isTrackOrderOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = query.trim().toLowerCase();
    if (!clean) return;

    const filtered = orders.filter((o) => {
      const matchId = o.id.toLowerCase().includes(clean);
      const matchPhone = o.customer.phone.includes(clean);
      const matchName = o.customer.name.toLowerCase().includes(clean);
      return matchId || matchPhone || matchName;
    });

    setMatchedOrders(filtered);
    setSearched(true);
  };

  const getStatusColor = (status: Order['orderStatus']) => {
    switch (status) {
      case 'Placed':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      case 'Processing':
        return 'text-sky-400 bg-sky-500/10 border-sky-500/30';
      case 'Shipped':
        return 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30';
      case 'Delivered':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
      case 'Cancelled':
        return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
      default:
        return 'text-neutral-400 bg-neutral-800 border-neutral-700';
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl relative my-auto">
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/70">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">
                {t('Track Your Order', 'ऑर्डर ट्रैक करें')}
              </h3>
              <p className="text-xs text-neutral-400">Scorpion In clothings Order Status</p>
            </div>
          </div>
          <button
            onClick={() => setIsTrackOrderOpen(false)}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 flex items-center justify-center text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Input */}
        <div className="p-5 border-b border-neutral-800/80 bg-neutral-950/40">
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Enter Order ID (e.g. SCP-84291) or 10-digit Phone"
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl pl-10 pr-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-neutral-500 outline-none transition-colors font-mono"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs sm:text-sm transition-colors cursor-pointer"
            >
              Track
            </button>
          </form>
        </div>

        {/* Results */}
        <div className="p-5 overflow-y-auto space-y-4">
          {!searched && matchedOrders.length === 0 && (
            <div className="text-center py-8 text-neutral-500 text-xs space-y-2">
              <Truck className="w-10 h-10 mx-auto text-neutral-600" />
              <p>अपना मोबाइल नंबर या ऑर्डर आईडी ऊपर डालकर सर्च करें।</p>
            </div>
          )}

          {searched && matchedOrders.length === 0 && (
            <div className="text-center py-8 text-neutral-400 text-xs space-y-2">
              <AlertCircle className="w-10 h-10 mx-auto text-amber-500" />
              <p className="font-semibold text-white">कोई ऑर्डर नहीं मिला।</p>
              <p className="text-neutral-500">
                कृपया चेक करें कि आपने सही ऑर्डर आईडी या फ़ोन नंबर दर्ज किया है।
              </p>
            </div>
          )}

          {matchedOrders.map((ord) => (
            <div
              key={ord.id}
              className="bg-neutral-950 border border-neutral-800 rounded-2xl p-4 space-y-3"
            >
              <div className="flex items-center justify-between border-b border-neutral-800/80 pb-2.5">
                <div>
                  <div className="text-[11px] text-neutral-500">Order ID</div>
                  <div className="font-mono font-bold text-amber-400 text-sm">{ord.id}</div>
                </div>
                <div className="text-right">
                  <span
                    className={`inline-block text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${getStatusColor(
                      ord.orderStatus
                    )}`}
                  >
                    ● {ord.orderStatus}
                  </span>
                  <div className="text-[11px] text-neutral-400 mt-0.5">
                    ₹{ord.totalAmount.toLocaleString('en-IN')} ({ord.paymentMethod.toUpperCase()})
                  </div>
                </div>
              </div>

              {/* Items */}
              <div className="space-y-1.5">
                {ord.items.map((it, i) => (
                  <div key={i} className="flex items-center justify-between text-xs text-neutral-300">
                    <span className="truncate max-w-[240px]">
                      {it.product.name} (Size: {it.selectedSize})
                    </span>
                    <span className="text-neutral-400 font-mono">x{it.quantity}</span>
                  </div>
                ))}
              </div>

              {/* Customer info */}
              <div className="text-[11px] text-neutral-400 bg-neutral-900/60 p-2.5 rounded-xl border border-neutral-800/60 flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <span className="truncate">
                  {ord.customer.name} • {ord.customer.city}, {ord.customer.state}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
