export type ProductCategory = 'all' | 'men' | 'women';
export type ProductSubCategory = 'all' | 't-shirts' | 'shirts' | 'jeans' | 'hoodies' | 'jackets' | 'oversized';

export type ProductSize = 'S' | 'M' | 'L' | 'XL' | 'XXL';

export interface ProductColor {
  name: string;
  hex: string;
}

export interface Product {
  id: string;
  name: string;
  hindiName?: string;
  category: 'men' | 'women';
  subCategory: 't-shirts' | 'shirts' | 'jeans' | 'hoodies' | 'jackets' | 'oversized';
  price: number; // in INR
  originalPrice: number; // MRP
  discountPercent: number;
  sizes: ProductSize[];
  colors: ProductColor[];
  images: string[];
  description: string;
  hindiDescription?: string;
  features: string[];
  fabric: string;
  fit: string;
  inStock: boolean;
  stockCount: number;
  rating: number;
  reviewsCount: number;
  badge?: 'Bestseller' | 'Trending' | 'New Arrival' | 'Hot Deal';
  isFeatured?: boolean;
}

export interface CartItem {
  id: string; // unique item id in cart (product.id + size + color)
  product: Product;
  selectedSize: ProductSize;
  selectedColor: ProductColor;
  quantity: number;
}

export type OrderStatus = 'Placed' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
export type PaymentMethod = 'upi' | 'cod';
export type PaymentStatus = 'pending' | 'verified' | 'paid';

export interface CustomerDetails {
  name: string;
  phone: string;
  email?: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  landmark?: string;
}

export interface Order {
  id: string; // e.g. SCP-84291
  createdAt: string; // ISO date string
  items: CartItem[];
  subtotal: number;
  shipping: number;
  discount: number;
  totalAmount: number;
  customer: CustomerDetails;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  upiTxnId?: string; // UTR or Ref number entered by customer
  notes?: string;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  upiId: string;
  upiPayeeName: string;
  whatsappNumber: string;
  contactPhone: string;
  supportEmail: string;
  freeShippingAbove: number;
  noticeBanner: string;
}
